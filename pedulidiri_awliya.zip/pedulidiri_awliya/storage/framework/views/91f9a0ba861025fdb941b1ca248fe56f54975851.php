<?php $__env->startSection('title', config('app.name', 'PEDULI DIRI') . ' | LOGIN'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-6">
        <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
            <div class="row">
                <div class="col-md-12 mb-5">
                    <h1 style="color:rgb(0, 0, 0)">LOGIN</h1>
                </div>
                <div class="col-lg-12">
                    <form action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <?php if(session('error-login')): ?>
                            <div class="row mb-3">
                                <div class="col-md-8">
                                    <label style="color:red;"><?php echo e(session('error-login')); ?></label>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="row mb-3">
                            <div class="col-md-8">
                                <label for="" style="color:white">Username</label>
                                <input type="text" name="username"
                                    class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="username"
                                    value="<?php echo e(old('username')); ?>" placeholder="Enter Username">
                                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-8">
                                <label for="" style="color:white">Password</label>
                                <input type="password" name="password"
                                    class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="password"
                                    placeholder="Password">
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-primary btn-block">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <style>
                            a {
                                color: blue;
                            }

                            a:hover {
                                Color: black;
                            }

                        </style>
                        <label for="">
                            Belum Punya Akun ?
                            <a href="<?php echo e(route('register')); ?>">Daftar di sini</a>
                        </label>
                    </div>
                </div>
                <div class="col-lg-12">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <img src="<?php echo e(asset('foto/sign.png')); ?>" alt="">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/auth/login.blade.php ENDPATH**/ ?>