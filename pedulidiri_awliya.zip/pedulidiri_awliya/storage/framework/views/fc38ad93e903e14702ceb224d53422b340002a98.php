<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

    <div class="container">
        <div class="col-md-12 left-content show-up header-text wow fadeInLeft">
            <div class="card">
                <div class="card-header">
                    <h1> Data User</h1>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <a href="/user/generate-pdf" class="btn btn-primary" target="_blank">CETAK PDF</a>
                            <table class="table table-responsive table-hover">
                                <thead>
                                    <th width="5%">No</th>
                                    <th width="15%">NIK</th>
                                    <th width="15%">Nama</th>
                                    <th width="15%">Email</th>
                                    <th width="15%">Telpon</th>
                                    <th width="15%">Username</th>
                                    <th width="10%">Role</th>
                                    <th width="10%"><a href="/user/create">Tambah Data User</a></th>
                                </thead>

                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->nik); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->telp); ?></td>
                                        <td><?php echo e($item->username); ?></td>
                                        <td><?php echo e($item->role); ?></td>
                                        <td>

                                            
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                                                    Action
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item"
                                                        href="/user/detail/<?php echo e($item->id); ?>">Detail</a>
                                                    <?php if($item->nik != Auth::user()->nik): ?>
                                                        <?php if($item->role != 'admin'): ?>
                                                            <a class="dropdown-item"
                                                                href="/user/delete/<?php echo e($item->id); ?>"
                                                                onclick="return confirm('Anda Yakin Ingin Menghapusnya?')">Hapus</a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                        </td>
                                    </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            Halaman
                            <?php echo e($user->currentPage()); ?>

                            Dari
                            <?php echo e($user->lastPage()); ?>


                            <?php echo e($user->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/user/index.blade.php ENDPATH**/ ?>