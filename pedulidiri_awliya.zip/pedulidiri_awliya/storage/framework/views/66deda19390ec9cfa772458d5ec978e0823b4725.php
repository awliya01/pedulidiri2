<div class="card">
    <div class="card-header pt-2">
        <h4>Profile</h4>
    </div>

    <img class="card-img-top"
        <?php if(Auth::user()->foto > 0): ?> src="<?php echo e(asset('foto/' . Auth::user()->foto)); ?>"  style="height: 250px;" <?php else: ?>
        src="<?php echo e(asset('foto/profile.png')); ?>"  style="height: 250px;" <?php endif; ?>
        alt="Card image cap">

    <div class="card-body">
        <h5 class="card-title"><?php echo e(Auth::user()->nama); ?></h5>

        <div class="row">
            <div class="col-md-4">
                <label for="email">Email</label>
            </div>
            <div class="col-md-8">
                <label>: <?php echo e(Auth::user()->email); ?></label>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <label for="telp">Telpon</label>
            </div>
            <div class="col-md-8">
                <label>: <?php echo e(Auth::user()->telp); ?></label>
            </div>
        </div>

        <?php if(Request::url() == route('perjalanan.data')): ?>
            <div class="row">
                <div class="col-md-12">
                    <a href="/user/show/<?php echo e(Auth::user()->id); ?>" class="btn btn-block btn-primary ">Profile</a>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/perjalanan/profile/main.blade.php ENDPATH**/ ?>