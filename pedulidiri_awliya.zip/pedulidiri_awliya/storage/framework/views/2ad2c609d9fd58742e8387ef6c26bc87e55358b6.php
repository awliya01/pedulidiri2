<?php $__env->startSection('content'); ?>
    <div class="col-lg-6">
        <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
            <div class="row">
                <div class="col-md-12 mb-5">
                    <h1 style="color:black">Register</h1>
                </div>
                <div class="col-lg-12">
                    <form action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="" style="color:white">NIK</label>
                                <input type="text" name="nik" class="form-control <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="nik" placeholder="Enter nik" value="<?php echo e(old('nik')); ?>"
                                    onkeypress="return onlyNumberKey(event)" maxlength="16">
                                <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="" style="color:white">Nama</label>
                                <input type="text" name="nama" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="nama" placeholder="Enter nama" value="<?php echo e(old('nama')); ?>">
                                <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="" style="color:white">Email</label>
                                <input type="text" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="" style="color:white">Nomor Telpon</label>
                                <input type="number" name="telp" class="form-control <?php if ($errors->has('telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="telp" placeholder="Enter telp" value="<?php echo e(old('telp')); ?>">
                                <?php if ($errors->has('telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telp'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="" style="color:white">Username</label>
                                <input type="text" name="username"
                                    class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="username"
                                    placeholder="Enter Username" value="<?php echo e(old('username')); ?>">
                                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="" style="color:white">Password</label>
                                <input type="password" name="password"
                                    class="form-control  <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="password"
                                    placeholder="Password">
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="" style="color:white">Confirm Password</label>
                                <input type="password" name="password_confirmation" class="form-control" id=""
                                    placeholder="Confirm Password">
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary btn-block">Register</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <style>
                                    a {
                                        color: blue;
                                    }

                                    a:hover {
                                        Color: black;
                                    }

                                </style>
                                <label for="">
                                    Sudah Punya Akun ?
                                    <a href="<?php echo e(route('login')); ?>">Login</a>
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-12">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <img src="<?php echo e(asset('foto/Sign up-amico.png')); ?>" alt="">
        </div>
    </div>

    <script>
        function onlyNumberKey(evt) {
            var code = (evt.which) ? evt.which : evt.keyCode
            if (code > 31 && code < 48 || code > 57) {
                return false;
            }
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/auth/register.blade.php ENDPATH**/ ?>