<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">


    <div class="col-lg-4 align-self-center">
        <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
            <div class="row">
                <div class="col-lg-12">
                    <?php echo $__env->make('perjalanan.profile.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-8">
        <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
            <div class="card">
                <div class="card-header">
                    <h1>Data Perjalanan</h1>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-responsive table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Tanggal Perjalanan</th>
                                    <th>Jam</th>
                                    <th>Lokasi</th>
                                    <th>Suhu Tubuh</th>
                                    <th>
                                        
                                        <a href="/diri/create">Tambah Data</a>
                                        
                                    </th>
                                </thead>

                                <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($no + 1); ?></td>
                                            <td><?php echo e($data->tanggal); ?></td>
                                            <td><?php echo e($data->jam); ?></td>
                                            <td><?php echo e($data->lokasi); ?></td>
                                            <td><?php echo e($data->suhu_tubuh); ?></td>
                                            <td>
                                                
                                                <a href="/diri/destroy/<?php echo e($data->id_perjalanan); ?>" class="btn btn-danger"
                                                    onclick="return confirm('Anda Yakin Ingin Menghapusnya?')">Hapus</a>
                                                
                                            </td>
                                        </tr>
                                    </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                            <div class="d-flex justify-content-start">
                                Halaman
                                <?php echo e($table->currentPage()); ?>


                                

                            </div>
                            

                            <?php echo e($table->links()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/perjalanan/index.blade.php ENDPATH**/ ?>