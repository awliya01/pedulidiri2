<div id="modal" class="popupContainer"
    style="display: none; width:80%;  opacity: 1; z-index: 11000; left: 50%; margin-left: -165px; top: 100px;">
    <div class="popupHeader">
        <span class="header_title">Login</span>
        <span class="modal_close"><i class="fa fa-times"></i></span>
    </div>

    <section class="popupBody">
        <!-- Social Login -->
        <div class="social_login">
            <div class="">
                

                
            </div>

            

            <div class="action_btns">
                <div class="one_half"><a href="<?php echo e(route('login')); ?>" class="btn">Login</a></div>
                <div class="one_half last"><a href="<?php echo e(route('register')); ?>"
                        class="btn">Sign up</a></div>
            </div>
        </div>

        <!-- Username & Password Login form -->
        <div class="user_login">
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <label>Username</label>
                        <input type="text" name="username">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <label>Password</label>
                        <input type="password" name="password">
                    </div>
                </div>


                <div class="row">
                    <div class="action_btns">
                        <div class="col-md-6">
                            <div class="one_half">
                                <a href="#" class="btn back_btn">
                                    <i class="fa fa-angle-double-left"></i> Back
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="one_half last">
                                <button type="submit" class="btn btn_red btn block">Login</button>
                            </div>
                        </div>
                    </div>
                </div>

            </form>

            
        </div>

        <!-- Register Form -->
        <div class="user_register">
            <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <label>NIK</label>
                        <input type="text">
                    </div>
                    <div class="col-md-6">
                        <label>Nama</label>
                        <input type="text" class="form-control">
                    </div>
                </div>

                <div class="row">

                </div>

                <div class="row">
                    <div class="col-md-6">
                        <label>Email</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label>Nomor Telpon</label>
                        <input type="number" class="form-control">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <label>Password</label>
                        <input type="password" class="form-control">
                    </div>

                    <div class="col-md-6">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control">
                    </div>
                </div>



                
                <div class="row">
                    <div class="col-md-6">
                        <div class="action_btns">
                            <div class="one_half"><a href="#" class="btn back_btn"><i
                                        class="fa fa-angle-double-left"></i> Back</a></div>
                            <div class="one_half last"><button type="submit" class="btn btn_red">Register</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\pedulidiri_awliya\resources\views/template/partikel/modal/auth.blade.php ENDPATH**/ ?>